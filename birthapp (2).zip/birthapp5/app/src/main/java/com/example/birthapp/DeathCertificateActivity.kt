package com.example.birthapp

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.Toast
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import io.appwrite.Client
import android.content.Intent
import io.appwrite.services.Storage
import io.appwrite.services.Databases
import io.appwrite.ID
import io.appwrite.Query
import io.appwrite.models.InputFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import android.content.ContentResolver

class DeathCertificateActivity : ComponentActivity() {
    private lateinit var client: Client
    private lateinit var storage: Storage
    private lateinit var database: Databases

    private var selectedFileUri: Uri? = null
    private lateinit var filePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_death_certificate)

        client = Client(this)
            .setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722")  // Replace with your project ID

        storage = Storage(client)
        database = Databases(client)

        val selectButton: Button = findViewById(R.id.select1)
        val uploadButton: Button = findViewById(R.id.upload1)

        selectButton.setOnClickListener { selectFile() }
        uploadButton.setOnClickListener { CoroutineScope(Dispatchers.Main).launch { handleFileUpload() } }

        filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedFileUri = result.data?.data
                Toast.makeText(this, "File selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*" // Adjust the MIME type as needed
        }
        filePickerLauncher.launch(intent)
    }

    private suspend fun handleFileUpload() {
        val uri = selectedFileUri ?: run {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show()
            return
        }

        // Generate hash of the selected file
        val fileHash = hashFile(uri)
       // Toast.makeText(this, "Generated Hash: $fileHash", Toast.LENGTH_SHORT).show()

        // Check if the hash exists in the database
        val hashExists = checkHashInDatabase(fileHash)
        if (hashExists) {
            uploadDocument(uri)
        } else {
            Toast.makeText(this, "Hash not found in database. Not uploading file.", Toast.LENGTH_SHORT).show()
        }
    }

    private suspend fun checkHashInDatabase(fileHash: String): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val response = database.listDocuments(
                databaseId = "66f45171002bbc202722",  // Your Database ID
                collectionId = "67307475003b117e6b9b",  // Replace with your actual collection ID for hashes
                queries = listOf(Query.equal("hash", fileHash))
            )
            response.documents.isNotEmpty()
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this@DeathCertificateActivity, "Error checking hash: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            false
        }
    }

    private fun uploadDocument(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val fileName = getFileName(uri)
                val tempFile = File.createTempFile("upload_", fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output -> input.copyTo(output) }
                }

                val file = InputFile.fromFile(tempFile)
                storage.createFile("66f5141a002a27027069", ID.unique(), file)

                // Navigate to the next activity after a successful file upload
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@DeathCertificateActivity, "File uploaded successfully!", Toast.LENGTH_SHORT).show()
                    navigateToDetailsOfDeathActivity() // Add this line
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@DeathCertificateActivity, "File upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun hashFile(uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(uri)?.use { inputStream ->
            val buffer = ByteArray(1024)
            var bytesRead: Int
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun getFileName(uri: Uri): String {
        var name = ""
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use {
                val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (it.moveToFirst()) {
                    name = it.getString(nameIndex)
                }
            }
        }
        return name.ifEmpty { "file_${System.currentTimeMillis()}.txt" }
    }

    private fun navigateToDetailsOfDeathActivity() {
        val intent = Intent(this, DetailsOfDeathActivity::class.java)
        startActivity(intent)
    }
}
