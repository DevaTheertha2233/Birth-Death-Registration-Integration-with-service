package com.example.birthapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home) // Ensure this matches the XML layout file name

        // Define your buttons
        val btnProfile: Button = findViewById(R.id.btnProfile)
        val btnBirthCertificate: Button = findViewById(R.id.btnBirthCertificate)
        val btnDeathCertificate: Button = findViewById(R.id.btnDeathCertificate)
        val btnChat: Button = findViewById(R.id.btnChat)  // Add this for the ChatBot button

        // Set up click listeners for existing buttons
        btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        btnBirthCertificate.setOnClickListener {
            startActivity(Intent(this, BirthCertificateActivity::class.java))
        }

        btnDeathCertificate.setOnClickListener {
            startActivity(Intent(this, DeathCertificateActivity::class.java))
        }

        // Set up click listener for btnChat to launch ChatBotActivity
        btnChat.setOnClickListener {
            startActivity(Intent(this, ChatBotActivity::class.java))  // Launch ChatBotActivity
        }
    }
}
