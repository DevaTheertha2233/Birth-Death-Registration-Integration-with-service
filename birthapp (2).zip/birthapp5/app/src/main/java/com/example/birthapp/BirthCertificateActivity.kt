package com.example.birthapp

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import io.appwrite.Client
import io.appwrite.services.Storage
import io.appwrite.services.Databases
import io.appwrite.models.InputFile
import io.appwrite.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import android.content.ContentResolver
import android.content.Intent

class BirthCertificateActivity : ComponentActivity() {
    private lateinit var client: Client
    private lateinit var storage: Storage
    private lateinit var database: Databases

    private var selectedAadharFileUri: Uri? = null
    private var selectedHospitalFileUri: Uri? = null
    private var selectedMarksFileUri: Uri? = null

    private lateinit var filePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_birth_certificate)

        client = Client(this)
            .setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722")

        storage = Storage(client)
        database = Databases(client)

        val aadharImg: ImageView = findViewById(R.id.aadharimg)
        val hospitalImg: ImageView = findViewById(R.id.hospitalimg)
        val marksImg: ImageView = findViewById(R.id.tenimg)

        aadharImg.setOnClickListener { selectFileForAadhar() }
        hospitalImg.setOnClickListener { selectFileForHospital() }
        marksImg.setOnClickListener { selectFileForMarks() }

        filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val uri = result.data?.data
                Log.d("FilePicker", "File selected: ${uri.toString()}")
                when {
                    selectedAadharFileUri == null -> selectedAadharFileUri = uri
                    selectedHospitalFileUri == null -> selectedHospitalFileUri = uri
                    selectedMarksFileUri == null -> selectedMarksFileUri = uri
                }
                Toast.makeText(this, "File selected", Toast.LENGTH_SHORT).show()
            } else {
                Log.d("FilePicker", "File selection failed or canceled")
                Toast.makeText(this, "File selection failed", Toast.LENGTH_SHORT).show()
            }
        }

        val uploadButton: Button = findViewById(R.id.upload)
        uploadButton.setOnClickListener { uploadDocuments() }
    }

    private fun selectFileForAadhar() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        filePickerLauncher.launch(intent)
    }

    private fun selectFileForHospital() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        filePickerLauncher.launch(intent)
    }

    private fun selectFileForMarks() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        filePickerLauncher.launch(intent)
    }

    private fun uploadDocuments() {
        if (selectedAadharFileUri == null || selectedHospitalFileUri == null || selectedMarksFileUri == null) {
            Toast.makeText(this, "Please select all files first!", Toast.LENGTH_SHORT).show()
            return
        }

        var uploadCount = 0
        val totalFiles = 3

        if (selectedAadharFileUri != null) {
            uploadFileToBucket(selectedAadharFileUri!!, "66f5141a002a27027069") {
                uploadCount++
                if (uploadCount == totalFiles) navigateToDetailsActivity()
            }
        }
        if (selectedHospitalFileUri != null) {
            uploadFileToBucket(selectedHospitalFileUri!!, "673ac459003bb8ffa2f4") {
                uploadCount++
                if (uploadCount == totalFiles) navigateToDetailsActivity()
            }
        }
        if (selectedMarksFileUri != null) {
            uploadFileToBucket(selectedMarksFileUri!!, "673ac44d002b3471de1f") {
                uploadCount++
                if (uploadCount == totalFiles) navigateToDetailsActivity()
            }
        }
    }

    private fun uploadFileToBucket(uri: Uri, bucketId: String, onUploadComplete: () -> Unit) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            inputStream?.let {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val fileHash = hashFile(uri)
                        Log.d("Upload", "Generated Hash for the image: $fileHash")

                        val hashExists = isHashExistsInDatabase(fileHash)
                        if (hashExists) {
                            val fileName = getFileName(uri)
                            val tempFile = File.createTempFile("upload_", fileName)
                            tempFile.outputStream().use { output -> inputStream.copyTo(output) }

                            Log.d("Upload", "Uploading file: ${getFileName(uri)} to bucket: $bucketId")
                            val file = InputFile.fromPath(tempFile.absolutePath)

                            val response = storage.createFile(bucketId, "unique_id", file)

                            runOnUiThread {
                                Log.d("Upload", "File uploaded successfully to bucket: $bucketId")
                                Toast.makeText(this@BirthCertificateActivity, "File uploaded successfully!", Toast.LENGTH_SHORT).show()
                            }
                            onUploadComplete() // Notify that upload is complete
                        } else {
                            runOnUiThread {
                                Toast.makeText(this@BirthCertificateActivity, "Hash not found in the database, file not uploaded", Toast.LENGTH_SHORT).show()
                                Log.d("Upload", "Hash not found, file not uploaded")
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Log.e("Upload", "Error during file upload: ${e.message}")
                            Toast.makeText(this@BirthCertificateActivity, "File upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("Upload", "Error opening file: ${e.message}")
            Toast.makeText(this, "Error opening file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToDetailsActivity() {
        val intent = Intent(this, DetailsActivity::class.java)
        startActivity(intent)
    }

    private fun hashFile(uri: Uri): String {
        val inputStream = contentResolver.openInputStream(uri)
        val digest = MessageDigest.getInstance("SHA-256")
        inputStream?.let {
            val buffer = ByteArray(1024)
            var bytesRead: Int
            while (it.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        val hashedBytes = digest.digest()
        return hashedBytes.joinToString("") { "%02x".format(it) }
    }

    private suspend fun isHashExistsInDatabase(fileHash: String): Boolean {
        var hashExists = false
        try {
            val response = withContext(Dispatchers.IO) {
                database.listDocuments(
                    databaseId = "66f45171002bbc202722",
                    collectionId = "67307475003b117e6b9b",
                    queries = listOf(Query.equal("hash", fileHash))
                )
            }
            hashExists = response.documents.isNotEmpty()
            Log.d("Database", "Hash found in database: $hashExists")
        } catch (e: Exception) {
            Log.e("Database", "Error checking for hash in the database: ${e.message}")
        }
        return hashExists
    }

    private fun getFileName(uri: Uri): String {
        val resolver: ContentResolver = contentResolver
        val cursor = resolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst()) {
                return it.getString(nameIndex)
            }
        }
        return "unknown_file"
    }
}