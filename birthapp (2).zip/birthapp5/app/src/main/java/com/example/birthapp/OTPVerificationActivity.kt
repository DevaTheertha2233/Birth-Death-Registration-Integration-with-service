package com.example.birthapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import io.appwrite.Client
import io.appwrite.services.Account
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OTPVerificationActivity : AppCompatActivity() {
    private lateinit var client: Client
    private lateinit var account: Account
    private var userId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp_login) // Corrected XML layout name

        // Initialize the Appwrite client
        client = Client(this)
            .setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722") // Replace with your project ID

        account = Account(client)

        // Retrieve the userId passed from MainActivity
        userId = intent.getStringExtra("userId") ?: ""

        // Initialize UI elements
        val otpDigits = arrayOf(
            findViewById<EditText>(R.id.otp_digit_1),
            findViewById<EditText>(R.id.otp_digit_2),
            findViewById<EditText>(R.id.otp_digit_3),
            findViewById<EditText>(R.id.otp_digit_4),
            findViewById<EditText>(R.id.otp_digit_5),
            findViewById<EditText>(R.id.otp_digit_6)
        )

        // Set up OTP EditTexts to move focus automatically
        setupOtpEditTexts(otpDigits)

        // Set up the verify button
        val verifyButton = findViewById<Button>(R.id.verify_button)
        verifyButton.setOnClickListener {
            val otp = otpDigits.joinToString("") { it.text.toString() }
            if (userId.isNotEmpty() && otp.length == 6) {
                verifyOtp(account, userId, otp) {
                    // Callback when login is successful
                    val intent = Intent(this@OTPVerificationActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish() // Close this activity
                }
            } else {
                Toast.makeText(this, "Please enter a valid OTP.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupOtpEditTexts(otpDigits: Array<EditText>) {
        for (i in otpDigits.indices) {
            otpDigits[i].addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    // Use safe call to check for null and access length
                    if (s != null && s.length == 1) {
                        if (i < otpDigits.size - 1) {
                            otpDigits[i + 1].requestFocus() // Move to next EditText
                        }
                    } else if (s.isNullOrEmpty() && i > 0) {
                        otpDigits[i - 1].requestFocus() // Move to previous EditText
                    }
                }

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })

            otpDigits[i].setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    otpDigits[i].setSelection(otpDigits[i].text.length)
                }
            }
        }
    }

    private fun verifyOtp(
        account: Account,
        userId: String,
        otp: String,
        onLoginSuccess: () -> Unit
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Verify OTP and create session
                account.createSession(userId, otp)

                // If successful, call onLoginSuccess
                onLoginSuccess()
            } catch (e: Exception) {
                CoroutineScope(Dispatchers.Main).launch {
                    // Use the activity context directly
                    Toast.makeText(this@OTPVerificationActivity, "Verification failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
