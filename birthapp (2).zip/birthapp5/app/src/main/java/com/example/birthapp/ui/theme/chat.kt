package com.example.birthapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log

class Chat : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("ChatActivity", "Chat activity started")
        setContentView(R.layout.activity_chatbot)
    }
}