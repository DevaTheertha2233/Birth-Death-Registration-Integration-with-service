package com.example.birthapp

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart

class EmailActivityd : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_emaild)

        // UI elements
        val emailInput = findViewById<TextInputEditText>(R.id.email_c)
        val sendEmailButton = findViewById<Button>(R.id.emailsendd)

        // Predefined sender credentials
        val senderEmail = "birthanddeathregistrar@gmail.com"
        val appPassword = "zmhn hohh zdmo insa"
        val subject = "Death Certificate"
        val body = "Your requested Death Certificate has been successfully created. Please find the attached Death certificate."

        // Get file path from intent
        val filePath = intent.getStringExtra("file_path")
        Log.d("EmailActivity", "Received file path: $filePath")

        // Set up button click listener
        sendEmailButton.setOnClickListener {
            val recipientEmail = emailInput.text.toString().trim()

            if (recipientEmail.isNotEmpty()) {
                sendEmailInBackground(senderEmail, appPassword, recipientEmail, subject, body, filePath)
            } else {
                Toast.makeText(this, "Please enter a valid email address.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendEmailInBackground(
        senderEmail: String,
        appPassword: String,
        recipientEmail: String,
        subject: String,
        body: String,
        filePath: String?
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val properties = System.getProperties().apply {
                    put("mail.smtp.host", "smtp.gmail.com")
                    put("mail.smtp.port", "587")
                    put("mail.smtp.auth", "true")
                    put("mail.smtp.starttls.enable", "true")
                }

                val session = Session.getInstance(properties, object : javax.mail.Authenticator() {
                    override fun getPasswordAuthentication() =
                        PasswordAuthentication(senderEmail, appPassword)
                })

                val message = MimeMessage(session).apply {
                    setFrom(InternetAddress(senderEmail))
                    addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                    setSubject(subject)
                }

                val multipart = MimeMultipart()
                val bodyPart = MimeBodyPart().apply { setText(body) }
                multipart.addBodyPart(bodyPart)

                filePath?.let {
                    val file = File(it)
                    if (file.exists()) {
                        val attachment = MimeBodyPart().apply { attachFile(file) }
                        multipart.addBodyPart(attachment)
                    }
                }

                message.setContent(multipart)
                Transport.send(message)

                withContext(Dispatchers.Main) {
                    Toast.makeText(this@EmailActivityd, "Email sent successfully!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("EmailActivity", "Error sending email: ${e.message}")
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@EmailActivityd, "Failed to send email.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
