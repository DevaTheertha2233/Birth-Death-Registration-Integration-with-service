package com.example.birthapp

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class DetailsActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var genderEditText: EditText
    private lateinit var dobEditText: EditText
    private lateinit var placeOfBirthEditText: EditText
    private lateinit var registrationDateEditText: EditText
    private lateinit var motherNameEditText: EditText
    private lateinit var fatherNameEditText: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // Initialize UI components
        nameEditText = findViewById(R.id.docname)
        genderEditText = findViewById(R.id.docgender)
        dobEditText = findViewById(R.id.docdateofbirth)
        placeOfBirthEditText = findViewById(R.id.dochospital)
        registrationDateEditText = findViewById(R.id.dateofregistration)
        motherNameEditText = findViewById(R.id.docmother)
        fatherNameEditText = findViewById(R.id.docfather)
        submitButton = findViewById(R.id.submitbutton)

        submitButton.setOnClickListener {
            Log.d("DetailsActivity", "Submit button clicked!")
            generateCertificate()
        }
    }

    private fun generateCertificate() {
        // Retrieve values from EditTexts
        val name = nameEditText.text.toString()
        val gender = genderEditText.text.toString()
        val dob = dobEditText.text.toString()
        val placeOfBirth = placeOfBirthEditText.text.toString()
        val registrationDate = registrationDateEditText.text.toString()
        val motherName = motherNameEditText.text.toString()
        val fatherName = fatherNameEditText.text.toString()

        Log.d("DetailsActivity", "Form data - Name: $name, Gender: $gender, DOB: $dob, Place of Birth: $placeOfBirth, " +
                "Registration Date: $registrationDate, Mother: $motherName, Father: $fatherName")

        // Prepare certificate content
        val certificateContent = """
                ಸರಕಾರ ಕರ್ನಾಟಕದ ರಾಷ್ಟ್ರ ರಾಜಧಾನಿ ಪ್ರದೇಶ
        Govt. of National Capital Territory of Karnataka

                        ಕನ್ನಡವೀಕರಣ
             Municipal Corporation of Karnataka

              ಜನನ ಪ್ರಮಾಣಪತ್ರ / Birth Certificate

(Issued under section 17 of the Registration of Birth and
Death Act,1969 and 8/13 of Delhi Registration of Birth Rule, 1999)

ಈ ಪ್ರಮಾಣಪತ್ರವು ಕೆಳಗಿನ ಮಾಹಿತಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುತ್ತದೆ, ಇದು ಕರ್ಣಾಟಕ ನಾರ್ತ್ 
ಜೋನ್‌ನ ಮುನ್ಸಿಪಲ್ ಕಾರ್ಪೊರೇಷನ್‌ನ ಮೂಲ ನೋಂದಣಿಯಿಂದ ತೆಗೆದುಕೊಂಡಿದೆ

This is to certify that the following information has been 
taken from the original record of Birth which is the register 
of Municipal Corporation of Karnataka North Zone

----------------------------------------------------------
|      Field                       |         Details      |
----------------------------------------------------------
  Name                             | $name                 
  Gender                           | $gender               
  Date of Birth                    | $dob                   
  Place of Birth                   | $placeOfBirth         
  Date of Registration             | $registrationDate     
  Name of Mother                   | $motherName           
  Name of Father                   | $fatherName           
----------------------------------------------------------

-----------------------------------
ENSURE REGISTRATION OF EVERY BIRTH & DEATH
-----------------------------------
Note: This certification is system generated and does not require 
any seal/signature in original.
The authenticity of this certificate can be verified at mcdonline.nic.in
-----------------------------------
        """.trimIndent()

        Log.d("DetailsActivity", "Certificate content generated: $certificateContent")

        // Save the certificate content to a text file and trigger email
        saveToFile(certificateContent)
    }

    private fun saveToFile(certificateContent: String) {
        try {
            // Get the path to the Downloads folder
            val downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsFolder, "Birth_certificate.txt")

            Log.d("DetailsActivity", "Saving certificate to file: ${file.absolutePath}")

            // Create or overwrite the file
            val fileOutputStream = FileOutputStream(file)
            val outputStreamWriter = OutputStreamWriter(fileOutputStream)

            // Write the certificate content to the file
            outputStreamWriter.write(certificateContent)
            outputStreamWriter.close()

            Log.d("DetailsActivity", "File saved successfully")

            // After saving the file, trigger the email sending
            sendEmailWithAttachment(file)

        } catch (e: Exception) {
            Log.e("DetailsActivity", "Error saving file: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun sendEmailWithAttachment(file: File) {
        // Trigger the email activity or process here (send file to users)
        // You can pass the file path as an extra in the Intent
        Log.d("DetailsActivity", "Sending email with file: ${file.absolutePath}")
        val intent = Intent(this, EmailActivity::class.java)
        intent.putExtra("file_path", file.absolutePath)
        startActivity(intent)
    }
}
