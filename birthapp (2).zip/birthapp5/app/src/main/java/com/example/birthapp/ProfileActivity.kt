package com.example.birthapp

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.Toast
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import io.appwrite.Client
import android.content.Intent
import io.appwrite.services.Storage
import io.appwrite.services.Databases
import io.appwrite.ID
import android.widget.EditText
import io.appwrite.Query
import io.appwrite.models.InputFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import androidx.appcompat.app.AppCompatActivity
import android.content.ContentResolver
import android.content.SharedPreferences

class ProfileActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var database: Databases
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        Log.d("ProfileActivity", "onCreate started")

        // Initialize UI components
        nameEditText = findViewById(R.id.name_in_profile)
        emailEditText = findViewById(R.id.EmailAddress)
        saveButton = findViewById(R.id.button)

        // Initialize Appwrite Client and Databases service
        val client = Client(this)
        client.setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722")
            .setSelfSigned(true)

        database = Databases(client)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE)

        // Set up save button click listener
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val email = emailEditText.text.toString()

            Log.d("ProfileActivity", "Save button clicked. Name: $name, Email: $email")

            if (name.isNotEmpty() && email.isNotEmpty()) {
                Log.d("ProfileActivity", "Fields are valid. Saving profile.")
                saveUserProfile(name, email) // Call function to save profile
                saveEmailLocally(email) // Save the email locally
            } else {
                Log.e("ProfileActivity", "Error: Please fill in both fields.")
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to save profile information to the Appwrite database
    private fun saveUserProfile(name: String, email: String) {
        Log.d("ProfileActivity", "saveUserProfile started. Saving profile for $name with email $email.")

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val data = mapOf("name" to name, "email" to email)

                Log.d("ProfileActivity", "Preparing to save profile in database: $data")

                // Save profile in the database
                val document = database.createDocument(
                    databaseId = "66f45171002bbc202722",  // Database ID
                    collectionId = "6736c094000a9367da13",  // Profile collection ID
                    data = data,
                    documentId = "unique()"  // Auto-generate a unique document ID
                )

                // Log successful document creation
                Log.d("ProfileActivity", "Profile saved successfully. Document ID: ${document.id}")

                // Notify user that the profile was saved
                Toast.makeText(this@ProfileActivity, "Profile saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // Handle errors
                Log.e("ProfileActivity", "Error saving profile: ${e.message}")
                Toast.makeText(this@ProfileActivity, "Error saving profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to save email locally using SharedPreferences
    private fun saveEmailLocally(email: String) {
        Log.d("ProfileActivity", "saveEmailLocally started. Saving email: $email")

        val editor = sharedPreferences.edit()
        editor.putString("user_email", email) // Save the email with key "user_email"
        editor.apply()

        Log.d("ProfileActivity", "Email saved locally: $email")
    }
}
